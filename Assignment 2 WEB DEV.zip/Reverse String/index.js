function reverseString() {
    console.log("Function is being called");
    const input = document.getElementById("inputString").value;
    const reversed = input.split("").reverse().join("");
    document.getElementById("result").textContent = "Reversed: " + reversed;
}