function checkPalindrome() {
    const input = document.getElementById("numberInput").value;
    const reversed = input.split("").reverse().join("");
    const isPalindrome = input === reversed;
    document.getElementById("palindromeResult").textContent = isPalindrome ? "It is a palindrome." : "It is not a palindrome.";
}