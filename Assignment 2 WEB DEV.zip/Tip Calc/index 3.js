function calculateTip() {
    const subtotal = parseFloat(document.getElementById("subtotal").value);
    const tipPercentage = parseFloat(document.getElementById("tipPercentage").value);
    const tipAmount = subtotal * (tipPercentage / 100);
    const total = subtotal + tipAmount;
    document.getElementById("totalResult").textContent = "Total including tip: $" + total.toFixed(2);
}